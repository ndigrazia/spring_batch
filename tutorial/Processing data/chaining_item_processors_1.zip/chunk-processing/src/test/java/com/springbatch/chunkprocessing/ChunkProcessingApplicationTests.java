package com.springbatch.chunkprocessing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChunkProcessingApplicationTests {

	@Test
	void contextLoads() {
	}

}
