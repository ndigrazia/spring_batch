package com.springbatch.exception;

public class MyException extends Exception {

	public MyException(String string) {
		// TODO Auto-generated constructor stub
	}

}
